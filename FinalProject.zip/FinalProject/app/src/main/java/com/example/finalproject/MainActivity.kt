package com.example.finalproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: AdapterRecyclerView

    private fun init(){
        recyclerView = findViewById(R.id.todolist)
        val data = ArrayList<DataRecycleView>()
        data.add(DataRecycleView("Membantu Ibu", "13.20", "Jam 10 bantu ibu bersih2 rumah", "05/07/03"))
        data.add(DataRecycleView("Membantu Ibu", "13.20", "Jam 10 bantu ibu bersih2 rumah", "05/07/03"))

        adapter = AdapterRecyclerView(data)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        init()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    fun setToMainActivity2(view: View) {
        startActivity(Intent(this, MainActivity2::class.java));
    }
}